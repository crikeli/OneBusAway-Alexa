var http = require('http'),
    AlexaSkill = require('./AlexaSkill'),
    APP_ID = 'amzn1.echo-sdk-ams.app.bde9ae8f-ec5a-41e5-a85e-2a18d1a466b3',
    OBA_KEY = 'ebce0d53-acf7-40a2-b98b-e6210f2a9ca0';

var url = function(stopId) {
    return 'http://api.pugetsound.onebusaway.org/api/where/arrivals-and-departures-for-stop/1_' + stopId + '.json?key=' + OBA_KEY;
};


var getJsonFromOba = function(stopId, callback) {
    http.get(url(stopId), function(res) {
        var body = '';

        res.on('data', function(data) {
            body += data;
        });

        res.on('end', function() {
            var result = JSON.parse(body);
            callback(result);
        });

    }).on('error', function(e) {
        console.log('Error: ' + e);
    });
};

var handleNextBusRequest = function(intent, session, response) {
    getJsonFromOba(intent.slots.bus.value, function(data) {
        if (data.data.entry.arrivalsAndDepartures[0]) {
            var text = data
                .data
                .entry
                .arrivalsAndDepartures[0]
                .numberOfStopsAway;
            // var ETA = data
            //     .data
            //     .entry
            //     .arrivalsAndDepartures[0]
            //     .predictedArrivalTime;
            // var right_now = new Date(ETA).getHours().getMinutes();
            var moreInfo = data
                .data
                .entry
                .arrivalsAndDepartures[0]
                .routeShortName;
            var destination = data
                .data
                .entry
                .arrivalsAndDepartures[0]
                .tripHeadsign
            var output = 'The next bus is route number ' + moreInfo + ', heading to ' + destination + '. It is currently ' + text + ' stops away.';
            // and scheduled to arrive at ' + right_now;
        } else {
            var text = 'That bus stop does not exist.'
            var output = text;
        }

        var heading = 'Next bus for stop: ' + intent.slots.bus.value;
        response.tell(output, heading);
    });
};

var BusSchedule = function() {
    AlexaSkill.call(this, APP_ID);
};

BusSchedule.prototype = Object.create(AlexaSkill.prototype);
BusSchedule.prototype.constructor = BusSchedule;

BusSchedule.prototype.eventHandlers.onLaunch = function(launchRequest, session, response) {
    // This is when they launch the skill but don't specify what they want. Prompt
    // them for their bus stop
    var output = 'Welcome to Bus Schedule. ' +
        'Say the number of a bus stop to know how far away the next bus is .';

    var reprompt = 'Which bus stop do you want to find more about?';

    response.ask(output, reprompt);

    console.log("onLaunch requestId: " + launchRequest.requestId + ", sessionId: " + session.sessionId);
};

BusSchedule.prototype.intentHandlers = {
    GetNextBusIntent: function(intent, session, response) {
        handleNextBusRequest(intent, session, response);
    },

    HelpIntent: function(intent, session, response) {
        var speechOutput = 'Get the distance from arrival for any Seattle bus stop ID. ' +
            'Which bus stop would you like?';
        response.ask(speechOutput);
    }
};

exports.handler = function(event, context) {
    var skill = new BusSchedule();
    skill.execute(event, context);
};